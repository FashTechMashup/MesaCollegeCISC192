//
//  main.cpp
//  Test
//
//  Created by Crystal Crawford on 8/29/17.
//  Copyright © 2017 Crystal Crawford. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
